export interface Testimonial {
  id: string;
  video: string;
  poster: string;
}

export interface TestimonialFormData {
  video: string;
  poster: string;
}
