export interface Reel {
  id: string;
  video: string;
  poster: string;
}

export interface ReelFormData {
  video: string;
  poster: string;
}
