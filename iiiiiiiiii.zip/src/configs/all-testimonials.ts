const testimonials = [
  {
    video:
      "https://jaikvik.in/lab/new-post-video/video/testimonial-video/1-client.mp4",
    poster: "/images/testimonial_video/poster/laxmi.png",
  },
  {
    video:
      "https://jaikvik.in/lab/new-post-video/video/testimonial-video/2-client-review.mp4",
    poster: "/images/testimonial_video/poster/celestail.png",
  },
  {
    video:
      "https://jaikvik.in/lab/new-post-video/video/testimonial-video/client-review-3.mp4",
    poster: "/images/testimonial_video/poster/micro_industeries.png",
  },
  {
    video:
      "https://jaikvik.in/lab/new-post-video/img/testimoinal/istockphoto-1321644229-640_adpp_is.mp4",
    poster: "/images/poster2.png",
  },
  {
    video:
      "https://jaikvik.in/lab/new-post-video/img/testimoinal/istockphoto-1321644229-640_adpp_is.mp4",
    poster: "/images/poster2.png",
  },
];

export default testimonials;
