const galleryImages = [
  "https://jaikvik.in/lab/new-post-video/banners/accessories-1.jpg",
  "https://jaikvik.in/lab/new-post-video/banners/arc-315.jpg",
  "https://jaikvik.in/lab/new-post-video/banners/mig-welding-torch-1.jpg",
  "https://jaikvik.in/lab/new-post-video/banners/acoustic-nest-banners-5.jpg",
];

export default galleryImages;