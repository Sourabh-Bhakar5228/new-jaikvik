const videos = [
  {
    src: "https://jaikvik.in/lab/new-post-video/videos/1.mp4",
    poster: "  /images/video_poster/cmed_1.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/videos/2.mp4",
    poster: "  /images/video_poster/indain_roller_2.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/videos/3.mp4",
    poster: "  /images/video_poster/envirotech_3.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/thumbnail/video/4.mp4",
    poster: "  /images/video_poster/4.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/thumbnail/video/5.mp4",
    poster: "  /images/video_poster/5.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/thumbnail/video/6.mp4",
    poster: "  /images/video_poster/6.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/thumbnail/video/7.mp4",
    poster: "  /images/video_poster/7.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/thumbnail/video/8.mp4",
    poster: "  /images/video_poster/8.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/thumbnail/video/9.mp4",
    poster: "  /images/video_poster/9.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/thumbnail/video/10.mp4",
    poster: "  /images/video_poster/10.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/videos/11.mp4",
    poster: "  /images/video_poster/11.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/thumbnail/video/12.mp4",
    poster: "  /images/video_poster/12.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/videos/13.mp4",
    poster: "  /images/video_poster/13.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/thumbnail/video/14.mp4",
    poster: "  /images/video_poster/14.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/thumbnail/video/15.mp4",
    poster: "  /images/video_poster/15.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/thumbnail/video/16.mp4",
    poster: "  /images/video_poster/16.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/videos/17.mp4",
    poster: "  /images/video_poster/17.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/videos/18.mp4",
    poster: "  /images/video_poster/18.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/thumbnail/video/19.mp4",
    poster: "  /images/video_poster/19.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/thumbnail/video/20.mp4",
    poster: "  /images/video_poster/20.png",
  },
  {
    src: "https://jaikvik.in/lab/new-post-video/videos/GSB-Video.mp4",
    poster: "/images/video_poster/gsb_video.png",
  },
];

export default videos;
