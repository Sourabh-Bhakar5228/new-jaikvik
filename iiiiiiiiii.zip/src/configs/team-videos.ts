const teamVideos = [
  {
    video:
      "https://jaikvik.in/lab/new-post-video/img/testimoinal/istockphoto-1321644229-640_adpp_is.mp4",
    poster: "/images/poster2.png",
  },
  {
    video:
      "https://jaikvik.in/lab/new-post-video/img/testimoinal/istockphoto-1321644229-640_adpp_is.mp4",
    poster: "/images/poster2.png",
  },
  {
    video:
      "https://jaikvik.in/lab/new-post-video/img/testimoinal/istockphoto-1321644229-640_adpp_is.mp4",
    poster: "/images/poster2.png",
  },
  {
    video:
      "https://jaikvik.in/lab/new-post-video/img/testimoinal/istockphoto-1321644229-640_adpp_is.mp4",
    poster: "/images/poster2.png",
  },
  {
    video:
      "https://jaikvik.in/lab/new-post-video/img/testimoinal/istockphoto-1321644229-640_adpp_is.mp4",
    poster: "/images/poster2.png",
  },
  {
    video:
      "https://jaikvik.in/lab/new-post-video/img/testimoinal/istockphoto-1321644229-640_adpp_is.mp4",
    poster: "/images/poster2.png",
  },
  {
    video:
      "https://jaikvik.in/lab/new-post-video/img/testimoinal/istockphoto-1321644229-640_adpp_is.mp4",
    poster: "/images/poster2.png",
  },
  {
    video:
      "https://jaikvik.in/lab/new-post-video/img/testimoinal/istockphoto-1321644229-640_adpp_is.mp4",
    poster: "/images/poster2.png",
  },
];

export default teamVideos;
