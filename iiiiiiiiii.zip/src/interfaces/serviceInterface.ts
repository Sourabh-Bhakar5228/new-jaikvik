export default interface serviceInterface {
    badge?: string,
    mainImg?: string,
    galleryImgs?: { src: string, alt: string }[],
    title?: string,
    description?: string,
    link?: string,
}